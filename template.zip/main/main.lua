debug = true

function love.load(arg)
end

function love.update(dt)
end

function love.draw(dt)
end


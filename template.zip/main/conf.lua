-- Configuration
function love.conf(t)
end